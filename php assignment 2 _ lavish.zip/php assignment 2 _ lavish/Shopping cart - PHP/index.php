<?php
session_start();

// Check if the user is logged in, if not, redirect to login page
if (!isset($_SESSION['login'])) {
    header('location: login.php');
    exit;
}

// Include the required function.php file
require 'function.php';

// Fetch all data from the 'siswa' table ordered by 'nis' in descending order
$students = getAllStudents();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Add your meta tags, title, and CSS links -->
    <!-- ... -->
</head>

<body>
    <!-- Add your navbar and container structure -->
    <!-- ... -->
    <div class="container">
        <div class="row my-2">
            <div class="col-md">
                <h3 class="text-center fw-bold text-uppercase">All Added Products</h3>
                <hr>
            </div>
        </div>
        <div class="row my-2">
            <div class="col-md">
                <a href="addData.php" class="btn btn-primary"><i class="bi bi-person-plus-fill"></i>&nbsp;Add Product</a>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-md">
                <div class="shell">
                    <div class="container">
                        <div class="row">
                            <?php foreach ($students as $student) : ?>
                                <div class="col-md-3">
                                    <div class="wsk-cp-product">
                                        <div class="wsk-cp-img">
                                            <img src=<?= "img/{$student['gambar']}"; ?> width="50%">
                                        </div>
                                        <div class="wsk-cp-text">
                                            <div class="category">
                                                <span><?= $student['nama']; ?></span>
                                            </div>
                                            <div class="title-product">
                                                <h3><?= $student['tmpt_Lahir']; ?></h3>
                                            </div>
                                            <div class="description-prod">
                                                <a href="ubah.php?nis=<?= $student['nis']; ?>" class="btn btn-warning btn-sm" style="font-weight: 600;"><i class="bi bi-pencil-square"></i>&nbsp;Edit Product</a>
                                                <a href="hapus.php?nis=<?= $student['nis']; ?>" class="btn btn-danger btn-sm" style="font-weight: 600;" onclick="return confirm('Are you sure you want to delete <?= $student['nama']; ?>?');"><i class="bi bi-trash-fill"></i>&nbsp;Delete Product</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ... -->
    <!-- Add your modal and footer -->
    <!-- ... -->
</body>

</html>
