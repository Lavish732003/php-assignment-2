<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Custom CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }

        /* Your custom CSS styles can go here */

    </style>

    <title>Shopping Cart - Add Product</title>
</head>

<body>
    <!-- Custom Navbar -->
    <nav>
        <!-- Your custom navbar code here -->
    </nav>
    <!-- Close Navbar -->

    <!-- Custom Container -->
    <div class="container">
        <div class="row my-2">
            <div class="col-md">
                <h3 class="fw-bold text-uppercase"><i class="bi bi-person-plus-fill"></i>&nbsp;Add New Product</h3>
            </div>
            <hr>
        </div>
        <div class="row my-2">
            <div class="col-md">
                <div class="custom-form-wrapper">
                    <!-- Your custom form code here -->
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-field">
                            <label for="productID">Product ID</label>
                            <input type="number" name="productID" id="productID" required>
                        </div>
                        <div class="form-field">
                            <label for="productName">Product Name</label>
                            <input type="text" name="productName" id="productName" required>
                        </div>
                        <div class="form-field">
                            <label for="productDescription">Product Description</label>
                            <textarea name="productDescription" id="productDescription" required></textarea>
                        </div>
                        <div class="form-field">
                            <label for="productImage">Product Image Upload</label>
                            <input class="file-input" id="productImage" name="productImage" type="file">
                        </div>
                        <div class="form-field">
                            <input type="submit" name="submit" value="Add Product">
                        </div>
                        <a href="index.php" class="btn-return">Return to Dashboard</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Close Container -->

    <!-- Custom Footer -->
    <footer>
        <!-- Your custom footer code here -->
    </footer>
    <!-- Close Footer -->

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous"></script>
</body>

</html>
