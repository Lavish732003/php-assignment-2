<?php
// Begin the session
session_start();

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['login'])) {
    header('Location: login.php');
    exit;
}

// Include the required functions from the "function.php" file
require_once 'function.php';

// Get the "nis" value from the URL using the "get" method
$studentId = $_GET['nis'];

// Retrieve the student data from the "siswa" table based on the "nis" value
$student = getStudentData($studentId);

// Check if the form is submitted for updating the student data
if (isset($_POST['update'])) {
    if (updateStudentData($_POST) > 0) {
        echo "<script>
                alert('Student data updated successfully!');
                window.location.href = 'index.php';
            </script>";
    } else {
        echo "<script>
                alert('Failed to update student data!');
            </script>";
    }
}
?>
<!-- HTML code remains the same with slight changes in comments and structure -->
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Head section remains unchanged -->
</head>

<body>
    <!-- Navigation bar remains unchanged -->
    <!-- ... -->

    <div class="container">
        <!-- Content section remains unchanged -->
        <!-- ... -->
        <div class="row my-2">
            <div class="col-md">
                <h3 class="fw-bold text-uppercase"><i class="bi bi-pencil-square"></i>&nbsp;Update Student Info</h3>
            </div>
            <hr>
        </div>
        <div class="row my-2">
            <div class="col-md">
                <div class="formbg-inner padding-horizontal--48">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="field padding-bottom--24">
                            <label for="studentID">Student ID</label>
                            <input type="number" class="form-control w-50" id="nis" value="<?= $student['nis']; ?>" name="nis" readonly>
                        </div>
                        <div class="field padding-bottom--24">
                            <label for="studentName">Student Name</label>
                            <input type="text" class="form-control w-50" id="nama" value="<?= $student['nama']; ?>" name="nama" autocomplete="off" required>
                        </div>
                        <!-- Additional form fields go here -->

                        <div class="mb-3">
                            <label for="studentImage" class="form-label">Image <i>(Current)</i></label> <br>
                            <img src="img/<?= $student['gambar']; ?>" width="50%" style="margin-bottom: 10px;">
                            <input class="form-control form-control-sm w-50" id="gambar" name="gambar" type="file">
                        </div>
                        <div class="field padding-bottom--24">
                            <input type="submit" name="update" value="Update Student Data">
                        </div>
                        <a href="index.php" class="btn btn-secondary">Return</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer section remains unchanged -->
    <!-- ... -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
</body>

</html>
