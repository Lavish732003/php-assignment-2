<?php
// Start the session
session_start();

// Clear all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the homepage
header('Location: home.php');
// This code clears all session data and logs the user out, then redirects them to the homepage.
