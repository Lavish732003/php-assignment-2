<?php
session_start();

// Check if the user is logged in, if not, redirect to login page
if (!isset($_SESSION['login'])) {
    header('location: login.php');
    exit;
}

// Include the required function.php file
require 'function.php';

// Get the 'nis' value from the query string using GET method
$studentId = $_GET['nis'];

// Attempt to delete student data
if (deleteStudent($studentId) > 0) {
    echo "<script>
            alert('Student data has been successfully deleted');
            window.location.href = 'index.php';
          </script>";
} else {
    echo "<script>
            alert('Failed to delete student data!');
          </script>";
}
?>
