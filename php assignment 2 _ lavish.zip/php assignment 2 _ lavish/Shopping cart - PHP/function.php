<?php
// Database Connection
$connection = mysqli_connect("localhost", "root", "", "crud2");

// Function to execute a query and return an array of results
function fetch_data($query)
{
    global $connection;

    $result = mysqli_query($connection, $query);

    $rows = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    return $rows;
}

// Function to add new product
function add_product($data)
{
    global $connection;

    $productID = htmlspecialchars($data['productID']);
    $productName = htmlspecialchars($data['productName']);
    $productDescription = htmlspecialchars($data['productDescription']);
    $productImage = upload_image();

    if (!$productImage) {
        return false;
    }

    $query = "INSERT INTO products (productID, productName, productDescription, productImage) 
              VALUES ('$productID', '$productName', '$productDescription', '$productImage')";

    mysqli_query($connection, $query);

    return mysqli_affected_rows($connection);
}

// Function to delete product
function delete_product($productID)
{
    global $connection;

    mysqli_query($connection, "DELETE FROM products WHERE productID = '$productID'");
    return mysqli_affected_rows($connection);
}

// Function to update product information
function update_product($data)
{
    global $connection;

    $productID = $data['productID'];
    $productName = htmlspecialchars($data['productName']);
    $productDescription = htmlspecialchars($data['productDescription']);
    $oldImage = $data['productImage'];

    if ($_FILES['productImage']['error'] === 4) {
        $productImage = $oldImage;
    } else {
        $productImage = upload_image();
    }

    $query = "UPDATE products 
              SET productName = '$productName', productDescription = '$productDescription', productImage = '$productImage'
              WHERE productID = '$productID'";

    mysqli_query($connection, $query);

    return mysqli_affected_rows($connection);
}

// Function to upload product image
function upload_image()
{
    $fileName = $_FILES['productImage']['name'];
    $fileSize = $_FILES['productImage']['size'];
    $fileError = $_FILES['productImage']['error'];
    $tmpName = $_FILES['productImage']['tmp_name'];

    if ($fileError === 4) {
        echo "<script>alert('Please select an image first!');</script>";
        return false;
    }

    $allowedExtensions = ['jpg', 'jpeg', 'png'];
    $fileExtension = explode('.', $fileName);
    $fileExtension = strtolower(end($fileExtension));

    if (!in_array($fileExtension, $allowedExtensions)) {
        echo "<script>alert('Invalid file format! Only JPG, JPEG, and PNG files are allowed.');</script>";
        return false;
    }

    if ($fileSize > 3000000) {
        echo "<script>alert('Image size is too large! Please upload an image with a size of up to 3 MB.');</script>";
        return false;
    }

    $uniqueFileName = uniqid();
    $uniqueFileName .= '.';
    $uniqueFileName .= $fileExtension;

    move_uploaded_file($tmpName, 'img/' . $uniqueFileName);

    return $uniqueFileName;
}
?>
