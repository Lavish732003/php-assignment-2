<?php
// Start the session
session_start();

// Redirect to login.php if not logged in or accessed directly from the URL
if (!isset($_SESSION['login'])) {
    header('Location: login.php');
    exit;
}

// Include the required functions from the "function.php" file
require_once 'function.php';

// Retrieve all data from the "siswa" table ordered by "nis" in descending order
$students = getAllStudentsOrderedByNisDesc();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Head section remains unchanged -->
</head>

<body>
    <!-- Navbar remains unchanged -->
    <!-- ... -->

    <div class="container">
        <div class="row my-2">
            <div class="col-md">
                <h3 class="text-center fw-bold text-uppercase">All Products</h3>
                <hr>
            </div>
        </div>
        <div class="row my-2">
            <div class="col-md">
                <a href="index.php" class="btn btn-primary"><i class="bi bi-person-plus-fill"></i>&nbsp;To Add Product Login (Click Here)</a>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-md">
                <div class="shell">
                    <div class="container">
                        <div class="row">
                            <?php foreach ($students as $student) : ?>
                                <?php $productImage = $student['gambar']; ?>
                                <div class="col-md-3">
                                    <div class="wsk-cp-product">
                                        <div class="wsk-cp-img">
                                            <img src=<?= "img/$productImage"; ?> width="50%">
                                        </div>
                                        <div class="wsk-cp-text">
                                            <div class="category">
                                                <span><?= $student['nama']; ?></span>
                                            </div>
                                            <div class="title-product">
                                                <h3><?= $student['tmpt_Lahir']; ?></h3>
                                            </div>
                                            <!-- Additional product information goes here -->
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Close Container -->

    <!-- Modal Detail Data remains unchanged -->
    <!-- ... -->

    <!-- Footer remains unchanged -->
    <!-- ... -->

    <!-- JavaScript dependencies remain unchanged -->
    <!-- ... -->
</body>

</html>
